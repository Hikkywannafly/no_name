export * as MangadexApi from "./MangaDex";
