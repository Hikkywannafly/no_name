export { default as MangaCarousel } from "./mangaSlide";
